/*
* File name: EmpPayroll.java
*
* Programmer:Jeremy Howard
* ULID: jlhowa3
*
* Date: Sep 18, 2019
*
* Class: IT 168
* Lecture Section: 16
* Lecture Instructor: Tonya Pierce
* Lab Section: 17
* Lab Instructor: Kushal Sharma
*/

/**
* <insert class description here>
*
* @author Jeremy Howard
*
*/
public class EmpPayroll
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub

	}

}
