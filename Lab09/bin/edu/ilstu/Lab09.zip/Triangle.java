/*
* File name: Triangle.java
*
* Programmer:Jeremy Howard
* ULID: jlhowa3
*
* Date: Oct 21, 2019
*
* Class: IT 168
* Lecture Section: 16
* Lecture Instructor: Tonya Pierce
* Lab Section: 17
* Lab Instructor: Kushal Sharma
*/
package edu.ilstu;

import java.util.Scanner;

/**
 * <Create a triangle given an input of 1-50 >
 *
 * @author Jeremy Howard
 *
 */
public class Triangle
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter a number between 1-50 for the size of the triangle : ");
		int maxAsterisks = scan.nextInt();

		
		while(!(maxAsterisks>= 1 && maxAsterisks<=50)) {
			System.out.println("Your number is not between  1-50. Please try again.");
			System.out.print("Enter a number between 1-50 for the size of the triangle : ");
			 maxAsterisks = scan.nextInt();
			
		}
		
		for (int i = 0; i < maxAsterisks-1; i++)
		{
			

			for (int j = 0 ; j <= i; j++)
			{
   
				System.out.print("*");

				
			}

			System.out.println("");
		}

		for (int i = 0; i < maxAsterisks; i++)
		{
			

			for (int j = i; j < maxAsterisks; j++)
			{
   
				System.out.print("*");

				
			}

			System.out.println("");
		}

	}

	
}
