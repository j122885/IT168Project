package ilstu.edu;
/*
* File name: FirstClass.java
*
* Programmer:Jeremy Howard
* ULID: jlhowa3
*
* Date: Aug 28, 2019
*
* Class: IT 168
* Lecture Section: 16
* Lecture Instructor: Kushal Sharma
* Lab Section:17
* Lab Instructor:Tonya Pierce
*/

/**
* <A first program rearranging statements.>
*
* @author Jeremy Howard
*
*/
public class FirstClass
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		System.out.println("Welcome to IT 168!"); 

		System.out.print("My name is Jeremy Howard.\n"); 

		System.out.println("My major is Information Systems Web Development.\n"); 

		System.out.println("Java rules!\n"); 

		System.out.println("Let�s have fun!\n"); 

	}

}
