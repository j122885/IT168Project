/*
* File name: MileageCalculator.java
*
* Programmer:Jeremy Howard
* ULID: jlhowa3
*
* Date: Aug 28, 2019
*
* Class: IT 168
* Lecture Section: 16
* Lecture Instructor: Kushal Sharma
* Lab Section:17
* Lab Instructor:Tonya Pierce
*/
package ilstu.edu;

/**
* <Calculates the mileage by dividing the number of mile by gallons.>
*
* @author Jeremy Howard
*
*/
public class MileageCalculator
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
	  int miles = 152;
	  int gallon = 8;
	  double mileage = miles/gallon; //divides miles by gallons and stores the result
	  System.out.println(mileage);

	}

}
