package edu.istu;

import java.util.Scanner;

public class nameChanger
{

	public static void main(String[] args) //output was based on sample output. Did not specify the size of the array or if the user puts in how many names they want
	{
		Scanner scan = new Scanner(System.in);
		String [] names = new String[4];
		int counter = 0;
		while(counter < 4) {
		System.out.print("Enter a name (first and last): ");
		String name = scan.nextLine();
		names[counter] = name;
		counter++;
		
		}
		
		for(int i = 0; i < names.length; i++) {
			String first = names[i].substring( 0, names[i].indexOf(" "));
			String last =  names[i].substring(names[i].indexOf(" "));
			String lfn = last + ", " + first;
			names[i]=lfn;
			System.out.println();
			System.out.println(names[i]);
		}
		
		
		
		
		
	}

}
